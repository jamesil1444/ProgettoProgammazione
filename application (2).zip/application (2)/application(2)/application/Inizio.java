package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.stage.Stage;

public class Inizio {

    // Metodo per cambiare alla scena di login
    @FXML
    public void ScenaLogin(ActionEvent event) {
        // Cambia la scena alla schermata di login
        SceneManager.cambiaScena("Login.fxml", event);
    }

    // Metodo per gestire la chiusura della finestra
    @FXML
    public void ScenaChiusura(ActionEvent event) {
        // Ottieni lo stage dalla sorgente dell'evento
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        // Chiedi conferma per chiudere la finestra
        Chiusura.confermaChiusura(stage);
    }
}
