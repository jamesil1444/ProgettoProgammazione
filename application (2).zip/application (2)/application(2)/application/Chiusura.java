package application;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.util.Optional;

public class Chiusura {

    // Metodo statico per chiedere conferma prima di chiudere la finestra/stage
    public static void confermaChiusura(Stage stage) {
        // Crea un oggetto di tipo Alert di conferma
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        
        // Imposta il titolo della finestra di dialogo di conferma
        alert.setTitle("Conferma Uscita");
        
        // Imposta l'header della finestra di dialogo
        alert.setHeaderText("Sei sicuro di voler uscire?");
        
        // Imposta il messaggio di contenuto che chiede conferma all'utente
        alert.setContentText("Conferma per uscire o annulla per rimanere.");

        // Mostra la finestra di dialogo e attende la risposta dell'utente
        Optional<ButtonType> result = alert.showAndWait();
        
        // Se l'utente ha cliccato su "OK", chiudi lo stage (finestra)
        if (result.isPresent() && result.get() == ButtonType.OK) {
            stage.close();  // Chiude la finestra dell'applicazione
        }
    }
    
    public static boolean confermaChiusuraDati(Stage stage) {
        // Esempio di dialogo di conferma
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Conferma chiusura");
        alert.setHeaderText("Sei sicuro di voler uscire?");
        alert.setContentText("Conferma per uscire o annulla per rimanere.");

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }
}
